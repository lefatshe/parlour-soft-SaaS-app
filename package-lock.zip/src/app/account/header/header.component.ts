import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'acc-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.sass']
})
export class AccountHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

export class User {
  emailAddress: string;
  password: string;
  loginType: number;
}

export class ErrRes {
  show: boolean;
  displayText: string;
}


export class regUser {
  username: string;
  cellphone: string;
  password: string;
  confirmPassword: string;
  accountTypeId: number;
}

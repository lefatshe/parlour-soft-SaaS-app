export const config = {
  apiUrl: 'http://www.parloursoftweb.co.za/api'
};

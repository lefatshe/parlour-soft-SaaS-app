## Test Users

{username: "lefatshe@me.com", cellphone: 780568815, password: "Lefatshe@2070", confirmPassword: "Lefatshe@2070", accountTypeId: 1}
{username: "dev@webclinic.co.za", cellphone: 780568815, password: "Lefatshe@2070", confirmPassword: "Lefatshe@2070", accountTypeId: 1}

alias ng="/Users/bobbi/.npm-global/bin/ng"
